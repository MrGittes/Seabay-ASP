﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingApplication
{
    /// <summary>
    /// The BankAccount class, handles logic for bank accoutns.
    /// </summary>
    public class BankAccount
    {
        #region BA Variables
        private string _customerName;
        private double _balance;
        private bool _frozen = false;
        #endregion

        /// <summary>
        /// Struct for the BankAccount class, sets the initial values of the variables CustomerName and Balance.
        /// </summary>
        /// <param name="custName">Name to set for the customer</param>
        /// <param name="balance">Value to set for the account balance</param>
        public BankAccount(string custName, double balance)
        {
            _customerName = custName;
            _balance = balance;
        }

        #region Properties
        public string CustomerName
        {
            get { return _customerName; }
            set { _customerName = value; }
        }

        public double Balance
        {
            get { return _balance; }
            private set { _balance = value; }
        }

        #endregion

        /// <summary>
        /// Te Debit method, to draw money from the account.
        /// </summary>
        /// <param name="amount">Amount to subtract.</param>
        public void Debit(double amount)
        {
            if(_frozen)
            {
                throw new Exception("Account frozen");
            }
            if(amount > _balance)
            {
                throw new ArgumentOutOfRangeException("amount");
            }
            if(amount < 0)
            {
                throw new ArgumentOutOfRangeException("amount");
            }

            _balance -= amount; // FEL
        }

        /// <summary>
        /// The Credit method, to add money to the account.
        /// </summary>
        /// <param name="amount">Amount to add</param>
        public void Credit(double amount)
        {
            if(_frozen)
            {
                throw new Exception("Account frozen");
            }
            if(amount < 0)
            {
                throw new ArgumentOutOfRangeException("amount", amount, AmountSubZeroMessage);
            }
            _balance += amount;
        }

        /// <summary>
        /// The FreezeAccount method. Sets _freeze to true.
        /// </summary>
        private void FreezeAccount()
        {
            _frozen = true;
        }
        /// <summary>
        /// The UnFreezeAccount method. Sets _freeze to false.
        /// </summary>
        private void UnfreezeAccount()
        {
            _frozen = false;
        }
    }
}
